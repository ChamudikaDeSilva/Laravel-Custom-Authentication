@extends('contact.layout')
@section('content')

    <div class="card">
        <div class="card-header">Contact Form</div>
        <div class="card-body">
           <h2> Welcome !!!!!! </h2>
        </div>
    </div>

@stop
