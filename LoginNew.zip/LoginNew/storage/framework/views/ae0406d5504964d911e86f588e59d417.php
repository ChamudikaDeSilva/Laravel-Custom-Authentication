<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header">Contact Form</div>
        <div class="card-body">
           <h2> You are logged in !!!!!!! </h2>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('contact.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\LoginNew\resources\views/contact/thanks.blade.php ENDPATH**/ ?>